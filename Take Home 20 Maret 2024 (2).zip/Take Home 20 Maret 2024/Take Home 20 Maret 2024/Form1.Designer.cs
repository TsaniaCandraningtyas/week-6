﻿namespace Take_Home_20_Maret_2024
{
    partial class Shop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Shop));
            this.DGV_Product = new System.Windows.Forms.DataGridView();
            this.DGV_Category = new System.Windows.Forms.DataGridView();
            this.lb_product = new System.Windows.Forms.Label();
            this.lb_category = new System.Windows.Forms.Label();
            this.Lb_Nama2 = new System.Windows.Forms.Label();
            this.lb_details = new System.Windows.Forms.Label();
            this.lb_Nama = new System.Windows.Forms.Label();
            this.lb_Categorybawah = new System.Windows.Forms.Label();
            this.lb_Harga = new System.Windows.Forms.Label();
            this.lb_Stock = new System.Windows.Forms.Label();
            this.bt_All = new System.Windows.Forms.Button();
            this.bt_Filter = new System.Windows.Forms.Button();
            this.bt_AddP = new System.Windows.Forms.Button();
            this.tb_Stock = new System.Windows.Forms.TextBox();
            this.tb_Harga = new System.Windows.Forms.TextBox();
            this.cb_Category = new System.Windows.Forms.ComboBox();
            this.tb_Nama1 = new System.Windows.Forms.TextBox();
            this.bt_EditP = new System.Windows.Forms.Button();
            this.bt_RemoveP = new System.Windows.Forms.Button();
            this.tb_Nama2 = new System.Windows.Forms.TextBox();
            this.bt_RemoveC = new System.Windows.Forms.Button();
            this.bt_AddC = new System.Windows.Forms.Button();
            this.cb_product = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Product)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Category)).BeginInit();
            this.SuspendLayout();
            // 
            // DGV_Product
            // 
            this.DGV_Product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_Product.Location = new System.Drawing.Point(12, 46);
            this.DGV_Product.Name = "DGV_Product";
            this.DGV_Product.Size = new System.Drawing.Size(433, 203);
            this.DGV_Product.TabIndex = 0;
            this.DGV_Product.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_Product_CellClick);
            this.DGV_Product.Click += new System.EventHandler(this.DGV_Product_Click);
            // 
            // DGV_Category
            // 
            this.DGV_Category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_Category.Location = new System.Drawing.Point(494, 46);
            this.DGV_Category.Name = "DGV_Category";
            this.DGV_Category.Size = new System.Drawing.Size(237, 203);
            this.DGV_Category.TabIndex = 1;
            this.DGV_Category.Click += new System.EventHandler(this.DGV_Category_Click);
            // 
            // lb_product
            // 
            this.lb_product.AutoSize = true;
            this.lb_product.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_product.Location = new System.Drawing.Point(12, 14);
            this.lb_product.Name = "lb_product";
            this.lb_product.Size = new System.Drawing.Size(93, 25);
            this.lb_product.TabIndex = 2;
            this.lb_product.Text = "Product";
            // 
            // lb_category
            // 
            this.lb_category.AutoSize = true;
            this.lb_category.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_category.Location = new System.Drawing.Point(489, 14);
            this.lb_category.Name = "lb_category";
            this.lb_category.Size = new System.Drawing.Size(107, 25);
            this.lb_category.TabIndex = 3;
            this.lb_category.Text = "Category";
            // 
            // Lb_Nama2
            // 
            this.Lb_Nama2.AutoSize = true;
            this.Lb_Nama2.Location = new System.Drawing.Point(483, 269);
            this.Lb_Nama2.Name = "Lb_Nama2";
            this.Lb_Nama2.Size = new System.Drawing.Size(35, 13);
            this.Lb_Nama2.TabIndex = 4;
            this.Lb_Nama2.Text = "Nama";
            // 
            // lb_details
            // 
            this.lb_details.AutoSize = true;
            this.lb_details.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_details.Location = new System.Drawing.Point(19, 279);
            this.lb_details.Name = "lb_details";
            this.lb_details.Size = new System.Drawing.Size(85, 25);
            this.lb_details.TabIndex = 5;
            this.lb_details.Text = "Details";
            // 
            // lb_Nama
            // 
            this.lb_Nama.AutoSize = true;
            this.lb_Nama.Location = new System.Drawing.Point(30, 323);
            this.lb_Nama.Name = "lb_Nama";
            this.lb_Nama.Size = new System.Drawing.Size(35, 13);
            this.lb_Nama.TabIndex = 6;
            this.lb_Nama.Text = "Nama";
            // 
            // lb_Categorybawah
            // 
            this.lb_Categorybawah.AutoSize = true;
            this.lb_Categorybawah.Location = new System.Drawing.Point(30, 349);
            this.lb_Categorybawah.Name = "lb_Categorybawah";
            this.lb_Categorybawah.Size = new System.Drawing.Size(49, 13);
            this.lb_Categorybawah.TabIndex = 7;
            this.lb_Categorybawah.Text = "Category";
            // 
            // lb_Harga
            // 
            this.lb_Harga.AutoSize = true;
            this.lb_Harga.Location = new System.Drawing.Point(30, 377);
            this.lb_Harga.Name = "lb_Harga";
            this.lb_Harga.Size = new System.Drawing.Size(36, 13);
            this.lb_Harga.TabIndex = 8;
            this.lb_Harga.Text = "Harga";
            // 
            // lb_Stock
            // 
            this.lb_Stock.AutoSize = true;
            this.lb_Stock.Location = new System.Drawing.Point(31, 404);
            this.lb_Stock.Name = "lb_Stock";
            this.lb_Stock.Size = new System.Drawing.Size(35, 13);
            this.lb_Stock.TabIndex = 9;
            this.lb_Stock.Text = "Stock";
            // 
            // bt_All
            // 
            this.bt_All.Location = new System.Drawing.Point(164, 17);
            this.bt_All.Name = "bt_All";
            this.bt_All.Size = new System.Drawing.Size(50, 23);
            this.bt_All.TabIndex = 10;
            this.bt_All.Text = "All";
            this.bt_All.UseVisualStyleBackColor = true;
            this.bt_All.Click += new System.EventHandler(this.bt_All_Click);
            // 
            // bt_Filter
            // 
            this.bt_Filter.Location = new System.Drawing.Point(220, 17);
            this.bt_Filter.Name = "bt_Filter";
            this.bt_Filter.Size = new System.Drawing.Size(50, 23);
            this.bt_Filter.TabIndex = 11;
            this.bt_Filter.Text = "Filter";
            this.bt_Filter.UseVisualStyleBackColor = true;
            this.bt_Filter.Click += new System.EventHandler(this.bt_Filter_Click);
            // 
            // bt_AddP
            // 
            this.bt_AddP.Location = new System.Drawing.Point(196, 382);
            this.bt_AddP.Name = "bt_AddP";
            this.bt_AddP.Size = new System.Drawing.Size(66, 39);
            this.bt_AddP.TabIndex = 12;
            this.bt_AddP.Text = "Add Product";
            this.bt_AddP.UseVisualStyleBackColor = true;
            this.bt_AddP.Click += new System.EventHandler(this.bt_AddP_Click);
            // 
            // tb_Stock
            // 
            this.tb_Stock.Location = new System.Drawing.Point(85, 401);
            this.tb_Stock.Name = "tb_Stock";
            this.tb_Stock.Size = new System.Drawing.Size(100, 20);
            this.tb_Stock.TabIndex = 13;
            this.tb_Stock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Harga_KeyPress);
            // 
            // tb_Harga
            // 
            this.tb_Harga.Location = new System.Drawing.Point(85, 374);
            this.tb_Harga.Name = "tb_Harga";
            this.tb_Harga.Size = new System.Drawing.Size(100, 20);
            this.tb_Harga.TabIndex = 14;
            this.tb_Harga.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Harga_KeyPress);
            // 
            // cb_Category
            // 
            this.cb_Category.FormattingEnabled = true;
            this.cb_Category.Location = new System.Drawing.Point(85, 346);
            this.cb_Category.Name = "cb_Category";
            this.cb_Category.Size = new System.Drawing.Size(121, 21);
            this.cb_Category.TabIndex = 15;
            // 
            // tb_Nama1
            // 
            this.tb_Nama1.Location = new System.Drawing.Point(85, 320);
            this.tb_Nama1.Name = "tb_Nama1";
            this.tb_Nama1.Size = new System.Drawing.Size(300, 20);
            this.tb_Nama1.TabIndex = 16;
            this.tb_Nama1.TextChanged += new System.EventHandler(this.tb_Nama1_TextChanged);
            // 
            // bt_EditP
            // 
            this.bt_EditP.Location = new System.Drawing.Point(268, 382);
            this.bt_EditP.Name = "bt_EditP";
            this.bt_EditP.Size = new System.Drawing.Size(66, 39);
            this.bt_EditP.TabIndex = 17;
            this.bt_EditP.Text = "Edit Product";
            this.bt_EditP.UseVisualStyleBackColor = true;
            this.bt_EditP.Click += new System.EventHandler(this.bt_EditP_Click);
            // 
            // bt_RemoveP
            // 
            this.bt_RemoveP.Location = new System.Drawing.Point(340, 382);
            this.bt_RemoveP.Name = "bt_RemoveP";
            this.bt_RemoveP.Size = new System.Drawing.Size(66, 39);
            this.bt_RemoveP.TabIndex = 18;
            this.bt_RemoveP.Text = "Remove Product";
            this.bt_RemoveP.UseVisualStyleBackColor = true;
            this.bt_RemoveP.Click += new System.EventHandler(this.bt_RemoveP_Click);
            // 
            // tb_Nama2
            // 
            this.tb_Nama2.Location = new System.Drawing.Point(524, 266);
            this.tb_Nama2.Name = "tb_Nama2";
            this.tb_Nama2.Size = new System.Drawing.Size(207, 20);
            this.tb_Nama2.TabIndex = 19;
            // 
            // bt_RemoveC
            // 
            this.bt_RemoveC.Location = new System.Drawing.Point(665, 301);
            this.bt_RemoveC.Name = "bt_RemoveC";
            this.bt_RemoveC.Size = new System.Drawing.Size(66, 39);
            this.bt_RemoveC.TabIndex = 21;
            this.bt_RemoveC.Text = "Remove Category";
            this.bt_RemoveC.UseVisualStyleBackColor = true;
            this.bt_RemoveC.Click += new System.EventHandler(this.bt_RemoveC_Click);
            // 
            // bt_AddC
            // 
            this.bt_AddC.Location = new System.Drawing.Point(593, 301);
            this.bt_AddC.Name = "bt_AddC";
            this.bt_AddC.Size = new System.Drawing.Size(66, 39);
            this.bt_AddC.TabIndex = 20;
            this.bt_AddC.Text = "Add Category";
            this.bt_AddC.UseVisualStyleBackColor = true;
            this.bt_AddC.Click += new System.EventHandler(this.bt_AddC_Click);
            // 
            // cb_product
            // 
            this.cb_product.FormattingEnabled = true;
            this.cb_product.Location = new System.Drawing.Point(276, 19);
            this.cb_product.Name = "cb_product";
            this.cb_product.Size = new System.Drawing.Size(121, 21);
            this.cb_product.TabIndex = 22;
            this.cb_product.SelectedIndexChanged += new System.EventHandler(this.cb_product_SelectedIndexChanged);
            // 
            // Shop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(754, 450);
            this.Controls.Add(this.cb_product);
            this.Controls.Add(this.bt_RemoveC);
            this.Controls.Add(this.bt_AddC);
            this.Controls.Add(this.tb_Nama2);
            this.Controls.Add(this.bt_RemoveP);
            this.Controls.Add(this.bt_EditP);
            this.Controls.Add(this.tb_Nama1);
            this.Controls.Add(this.cb_Category);
            this.Controls.Add(this.tb_Harga);
            this.Controls.Add(this.tb_Stock);
            this.Controls.Add(this.bt_AddP);
            this.Controls.Add(this.bt_Filter);
            this.Controls.Add(this.bt_All);
            this.Controls.Add(this.lb_Stock);
            this.Controls.Add(this.lb_Harga);
            this.Controls.Add(this.lb_Categorybawah);
            this.Controls.Add(this.lb_Nama);
            this.Controls.Add(this.lb_details);
            this.Controls.Add(this.Lb_Nama2);
            this.Controls.Add(this.lb_category);
            this.Controls.Add(this.lb_product);
            this.Controls.Add(this.DGV_Category);
            this.Controls.Add(this.DGV_Product);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Shop";
            this.Text = "Shop";
            this.Load += new System.EventHandler(this.Shop_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Product)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Category)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView DGV_Product;
        private System.Windows.Forms.DataGridView DGV_Category;
        private System.Windows.Forms.Label lb_product;
        private System.Windows.Forms.Label lb_category;
        private System.Windows.Forms.Label Lb_Nama2;
        private System.Windows.Forms.Label lb_details;
        private System.Windows.Forms.Label lb_Nama;
        private System.Windows.Forms.Label lb_Categorybawah;
        private System.Windows.Forms.Label lb_Harga;
        private System.Windows.Forms.Label lb_Stock;
        private System.Windows.Forms.Button bt_All;
        private System.Windows.Forms.Button bt_Filter;
        private System.Windows.Forms.Button bt_AddP;
        private System.Windows.Forms.TextBox tb_Stock;
        private System.Windows.Forms.TextBox tb_Harga;
        private System.Windows.Forms.ComboBox cb_Category;
        private System.Windows.Forms.TextBox tb_Nama1;
        private System.Windows.Forms.Button bt_EditP;
        private System.Windows.Forms.Button bt_RemoveP;
        private System.Windows.Forms.TextBox tb_Nama2;
        private System.Windows.Forms.Button bt_RemoveC;
        private System.Windows.Forms.Button bt_AddC;
        private System.Windows.Forms.ComboBox cb_product;
    }
}

