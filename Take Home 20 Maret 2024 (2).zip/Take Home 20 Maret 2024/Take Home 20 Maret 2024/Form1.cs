﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Take_Home_20_Maret_2024
{
    public partial class Shop : Form
    {
        DataTable dtProdukSimpan = new DataTable();
        DataTable dtProdukTampil = new DataTable();
        DataTable dtCategory = new DataTable();
        List<string> kategoriunik = new List<string>();
        public Shop()
        {
            InitializeComponent();
        }

        private void Shop_Load(object sender, EventArgs e)
        {
            dtProdukTampil = new DataTable();
            dtProdukTampil.Columns.Add("ID Product");
            dtProdukTampil.Columns.Add("Nama Product");
            dtProdukTampil.Columns.Add("Harga");
            dtProdukTampil.Columns.Add("Stock");
            dtProdukTampil.Columns.Add("ID Category");

            cb_product.Enabled = false;
            bt_AddP.BackColor = Color.Gold;
            bt_EditP.BackColor = Color.Green;
            bt_RemoveP.BackColor = Color.Maroon;
            bt_AddC.BackColor = Color.Green;
            bt_RemoveC.BackColor = Color.Maroon;
            dtProdukSimpan.Columns.Add("ID Product");
            dtProdukSimpan.Columns.Add("Nama Product");
            dtProdukSimpan.Columns.Add("Harga");
            dtProdukSimpan.Columns.Add("Stock");
            dtProdukSimpan.Columns.Add("ID Category");
            dtProdukSimpan.Rows.Add("J001", "Jas Hitam", "100000", "10", "C1");
            dtProdukSimpan.Rows.Add("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            dtProdukSimpan.Rows.Add("T002", "T-Shirt Obsessive", "75000", "16", "C2");
            dtProdukSimpan.Rows.Add("R001", "Rok Mini", "82000", "26", "C3");
            dtProdukSimpan.Rows.Add("J002", "Jeans Biru", "90000", "5", "C4");
            dtProdukSimpan.Rows.Add("C001", "Celana Pendek Coklat", "60000", "11", "C4");
            dtProdukSimpan.Rows.Add("C002", "Cawat Blink-Blink", "1000000", "1", "C5");
            dtProdukSimpan.Rows.Add("R002", "Rocca Shirt", "50000", "8", "C2");
            DGV_Product.DataSource = dtProdukSimpan;
            dtCategory.Columns.Add("ID Category");
            dtCategory.Columns.Add("Nama Category");
            dtCategory.Rows.Add("C1", "Jas");
            dtCategory.Rows.Add("C2", "T-Shirt");
            dtCategory.Rows.Add("C3", "Rok");
            dtCategory.Rows.Add("C4", "Celana");
            dtCategory.Rows.Add("C5", "Cawat");
            DGV_Category.DataSource = dtCategory;

            for(int i = 0; i < dtCategory.Rows.Count; i++)
            {
                cb_product.Items.Add(dtCategory.Rows[i][1].ToString());
            }

            for (int j = 0; j < dtCategory.Rows.Count; j++)
            {
                cb_Category.Items.Add(dtCategory.Rows[j][1].ToString());
            }
            
        }

        private void DGV_Product_Click(object sender, EventArgs e)
        {
            
        }

        private void bt_RemoveP_Click(object sender, EventArgs e)
        {
            if (tes == true)
            {
                DGV_Product.DataSource = dtProdukSimpan;
            }
            string a = DGV_Product.CurrentRow.Cells[1].Value.ToString();
            for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
            {
                if (dtProdukSimpan.Rows[i][1].ToString() == a)
                {
                    dtProdukSimpan.Rows.RemoveAt(i); 
                    break;
                }
            }
            tb_Nama1.Text = "";
            cb_Category.Text = "";
            tb_Harga.Text = "";
            tb_Stock.Text = "";
        }

        private void DGV_Category_Click(object sender, EventArgs e)
        {
            tb_Nama2.Text = DGV_Category.CurrentRow.Cells[1].Value.ToString();
        }

        private void bt_RemoveC_Click(object sender, EventArgs e)
        {
            string a = DGV_Category.CurrentRow.Cells[0].Value.ToString();
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (dtCategory.Rows[i][0].ToString() == a)
                {
                    dtCategory.Rows.RemoveAt(i);
                }
            }
            tb_Nama2.Text = "";
        }

        private void bt_AddP_Click(object sender, EventArgs e)
        {
            if(tes == true)
            {
                DGV_Product.DataSource = dtProdukSimpan;
            }
            string IDProduk = "";
            int abe = 0;
            for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
            {
                if (dtProdukSimpan.Rows[i][1].ToString().Substring(0, 1) == tb_Nama1.Text.Substring(0, 1))
                {
                    abe = Convert.ToInt32(dtProdukSimpan.Rows[i][0].ToString().Substring(1,3));
                }
            }
            for (int j = 0; j < dtCategory.Rows.Count; j++)
            {
                if (cb_Category.SelectedItem == dtCategory.Rows[j][1])
                {
                    IDProduk = dtCategory.Rows[j][0].ToString(); 
                    break;
                }
            }
            dtProdukSimpan.Rows.Add(tb_Nama1.Text.Substring(0, 1).ToUpper() + "00" + (abe + 1).ToString(), tb_Nama1.Text, tb_Harga.Text, tb_Stock.Text, IDProduk);
        }

        private void bt_AddC_Click(object sender, EventArgs e)
        {
            bool ada = false;
            int a = dtCategory.Rows.Count - 1;
            string c = dtCategory.Rows[a][0].ToString().Substring(1,1);
            int nama = Convert.ToInt32(c) + 1;
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (tb_Nama2.Text == dtCategory.Rows[i][1].ToString())
                {
                    ada = true;
                    break;
                }
                else
                {
                    ada = false;
                }
            }
            if (ada == true)
            {
                MessageBox.Show("Error");
            }
            if (ada == false)
            {
                dtCategory.Rows.Add("C" + nama.ToString(), tb_Nama2.Text);
            }
            tb_Nama2.Text = "";
        }

        private void bt_All_Click(object sender, EventArgs e)
        {
            cb_product.Enabled = true;
            DGV_Product.DataSource = dtProdukSimpan;
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                cb_product.Items.Add(dtCategory.Rows[i][1].ToString());
            }
        }

        private void bt_Filter_Click(object sender, EventArgs e)
        {
            cb_product.Enabled = true;
        }
        private void PopulateComboBoxWithUniqueValues()
        {
            kategoriunik.Clear();
            foreach (DataGridViewRow row in DGV_Product.Rows)
            {
                if (row.Cells["Nama Category"].Value.ToString() != null && !kategoriunik.Contains(row.Cells["Nama Category"].Value.ToString()))
                {
                    kategoriunik.Add(row.Cells["Nama Category"].Value.ToString());
                    cb_product.Items.Add(row.Cells["Nama Category"].Value.ToString());
                }
            }
        }

        private void tb_Nama1_TextChanged(object sender, EventArgs e)
        {

        }

        private void bt_EditP_Click(object sender, EventArgs e)
        {
            if (tes == true)
            {
                DGV_Product.DataSource = dtProdukSimpan;
            }
            DataGridViewRow dgv = DGV_Product.CurrentRow;
            dgv.Cells[1].Value = tb_Nama1.Text;
            dgv.Cells[2].Value = tb_Harga.Text;
            dgv.Cells[3].Value = tb_Stock.Text;
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (cb_Category.SelectedItem.ToString() == dtCategory.Rows[i][1].ToString())
                {
                    dgv.Cells[4].Value = dtCategory.Rows[i][0];
                }
            }
            tb_Nama1.Text = "";
            cb_Category.Text = "";
            tb_Harga.Text = "";
            tb_Stock.Text = "";

        }
        bool tes = false;
        private void cb_product_SelectedIndexChanged(object sender, EventArgs e)
        {
            tes = true;
            dtProdukTampil.Clear();
            DGV_Product.DataSource = dtProdukTampil;
            string a = "";
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (cb_product.SelectedItem.ToString() == dtCategory.Rows[i][1].ToString())
                {
                    a = dtCategory.Rows[i][0].ToString();
                }
            }
           
            for (int i = 0;i < dtProdukSimpan.Rows.Count; i++)
            {
                if (a == dtProdukSimpan.Rows[i][4].ToString())
                {
                    dtProdukTampil.Rows.Add(dtProdukSimpan.Rows[i][0], dtProdukSimpan.Rows[i][1], dtProdukSimpan.Rows[i][2], dtProdukSimpan.Rows[i][3], dtProdukSimpan.Rows[i][4]);
                }
            }
            DGV_Product.ClearSelection();
            DGV_Category.ClearSelection();
        }

        private void DGV_Product_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            tb_Nama1.Text = DGV_Product.CurrentRow.Cells[1].Value.ToString();
            tb_Harga.Text = DGV_Product.CurrentRow.Cells[2].Value.ToString();
            tb_Stock.Text = DGV_Product.CurrentRow.Cells[3].Value.ToString();
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (DGV_Product.CurrentRow.Cells[4].Value.ToString() == dtCategory.Rows[i][0].ToString())
                {
                    cb_Category.Text = dtCategory.Rows[i][1].ToString();
                    break;
                }
            }
        }

        private void tb_Harga_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back;
        }
    }
}